#include <iostream>

using namespace std;

int main()
{
    cout << "BIODATA DIRI" << endl;
    cout << "================================" << endl;
    cout << "Nama    : Daiyan Akbar Setiyadi" << endl;
    cout << "NIM     : A11.2022.14707" << endl;
    cout << "Alamat  : Banyumanik, Semarang" << endl;
    cout << "TTL     : Semarang, 22 Juli 2004" << endl;
    cout << "Hobi    : Bermain Game" << endl;
    cout << "================================" << endl;
    return 0;
}
