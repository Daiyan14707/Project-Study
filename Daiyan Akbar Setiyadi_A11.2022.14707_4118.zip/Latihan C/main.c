#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("BIODATA DIRI\n");
    printf("================================\n");
    printf("Nama    : Daiyan Akbar Setiyadi\n");
    printf("NIM     : A11.2022.14707\n");
    printf("Alamat  : Banyumanik, Semarang\n");
    printf("TTL     : Semarang, 22 Juli 2022\n");
    printf("Hobi    : Bermain Game\n");
    printf("================================\n");
    return 0;
}
